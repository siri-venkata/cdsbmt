python 0consolodate.py
python 1get_entities.py
python utils/2small_index.py
python 3get_articles.py
python utils/4duplicate_title_counter.py
python 5get_content.py
python utils/6clean_content.py
python utils/7probabilities.py
